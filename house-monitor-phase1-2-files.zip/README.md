# house-monitor Phase 1/2 implementation overlay

このZIPは、現行 `house-monitor` に Phase 1（DB安定化）と Phase 2（詳細項目の品質監査・掲載状態/不足項目フィルター）を適用するファイル一式です。

## 収録ファイル
- `scripts/listing_lifecycle.py`: 掲載状態を保守的に扱う共通関数
- `scripts/detail_enrichment.py`: 土地・建物面積、間取り、築年月などの項目別監査
- `scripts/validate_db.py`: JSON DBのID重複、状態、数値、履歴重複、サイズ検証
- `tests/test_phase12.py`: 単体テスト
- `apply_phase12.py`: 既存 `main.py` / `index.html` / workflow を安全なアンカー編集で統合

## 適用
1. リポジトリをローカルにチェックアウトし、作業ブランチを作成。
2. ZIPを展開し、次を実行。

```bash
python apply_phase12.py /path/to/house-monitor
```

3. リポジトリ内で実行。

```bash
python -m compileall -q scripts
python -m unittest discover -s tests
python scripts/validate_db.py
```

4. `git diff` を確認してからコミットしてください。想定アンカーが見つからない場合は、スクリプトが書き込み前に停止します。

## 注意
- 検索失敗・空結果・通信制限は掲載終了の証拠にしません。
- 明示的な終了文言がある場合のみ `confirmed_ended`。
- 欠損値を推測で埋めません。
- この段階では実物件の曖昧一致による自動統合はしません。
- APIキーや秘密情報は追加・保存しません。
