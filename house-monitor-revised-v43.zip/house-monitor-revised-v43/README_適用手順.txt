house-monitor 修正版 v43 適用手順

このZIPはコード・設定・ワークフローの修正版です。data/ 内の既存JSONは含めていません。
既存データを削除・初期化せず、GitHubリポジトリ側の data/ を維持してください。

主な修正
- criteria が不明な物件を即座に除外せず、marketReviewStatus=pending として houses.json に保持。
- 明示的に条件外 (False) と判定された物件は市場候補DBから除外。
- 検索で再出現した物件の旧statusを先にactiveへ上書きしないことで、再掲載を検知。
- summary.json に条件別の pending/excluded 件数を出力。
- validate_data.py で4つの生成JSON、ID一意性、status、summary件数を検証。
- 観測履歴とsummaryをGitHub Actionsでコミット。
- UIに条件判定待ち／条件確認済みのラベルを表示。

適用方法
1. 現在のGitHubリポジトリをバックアップする。
2. ZIP内のファイルを同じ相対パスでリポジトリへ上書きする。
3. 既存の data/discovered_listings.json、data/houses.json、data/listing_observations.json、data/summary.json は消さない。
4. requirements.txt が既に存在する場合は依存関係を確認し、必要に応じて既存内容を維持しつつ統合する。
5. GitHub Actions を workflow_dispatch で手動実行する。
6. Actionsログの Output validation、criteria pending/excluded by field、詳細取得エラーを確認する。
7. GitHub Pagesで物件カードと掲載状態フィルターを確認する。

注意
- houses.json は「条件がすべて確認済みの物件」だけでなく、「明示的な条件外ではないが一部未判定の物件」も含む市場候補DBになります。未判定はUIで「条件判定待ち」と表示します。
- 「掲載終了」は売買成立を意味しません。掲載終了判定は健全な検索結果での未検出、または詳細ページ上の明示的な終了根拠に限ります。
- この環境からSUUMOへの実運転やGitHub Actionsの実行はできないため、適用後のActions実行ログによる確認が必要です。
